import React from "react";

const Footer = () =>{
    return (
        <footer>© 2025 TaskBuddy</footer>
    );
};

export default Footer;