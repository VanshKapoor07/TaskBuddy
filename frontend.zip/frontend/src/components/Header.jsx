import React from "react";
import { Link } from "react-router-dom";
import Button from "./Button";

const Header = () => {
  
  return (
    <header>
    <nav>
      
      <Link to="/"><Button text = "Home">Home</Button></Link>
  
      <Link to="/auth"><Button text = "Login/Signup">Login/Signup</Button></Link>
      
      <Link to="/teams"><Button text = "View teams!">View karo yr</Button></Link>
      
    </nav>
  </header>
  );
};

export default Header;
